import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { HomeRoutingModule } from './home-routing.module';
import { HomeLayoutComponent } from './home-layout/home-layout.component';
import { CarouselModule } from 'primeng/carousel';
import { HomeComponent } from '../../components/home/home.component';

import { DashbordComponent } from '../../components/home/dashbord/dashbord.component';

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { applyPolyfills, defineCustomElements } from '@briza/air/loader';
// import { defineCustomElements } from '../../../../node_modules/@briza/air/dist/esm/loader.js';
// defineCustomElements();

@NgModule({
  declarations: [HomeLayoutComponent, HomeComponent, DashbordComponent],
  imports: [CommonModule, HomeRoutingModule, CarouselModule, HttpClientModule],

  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class HomeModule {}
platformBrowserDynamic()
  .bootstrapModule(HomeModule)
  .catch((err) => console.error(err));
defineCustomElements();
